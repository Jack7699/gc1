// world.js — terrain, city layout, buildings, props, traffic signals and lighting helpers

const TILE = 8; // metres of facade per window texture tile
const PALETTE = [
  [0.78, 0.76, 0.72], [0.6, 0.66, 0.72], [0.85, 0.8, 0.7], [0.45, 0.5, 0.58],
  [0.9, 0.9, 0.92], [0.7, 0.5, 0.4], [0.55, 0.6, 0.5],
];

// Collects box geometry into one shared buffer for fast rendering (one draw call per material)
class GeoBuilder {
  constructor() { this.pos = []; this.nrm = []; this.uv = []; this.col = []; this.idx = []; }

  box(cx, cy, cz, w, h, d, c) {
    const hw = w / 2, hh = h / 2, hd = d / 2;
    const P = this.pos, N = this.nrm, UV = this.uv, C = this.col, I = this.idx;
    const faces = [
      [[1, 0, 0], [hw, -hh, hd], [hw, -hh, -hd], [hw, hh, -hd], [hw, hh, hd], d, h],
      [[-1, 0, 0], [-hw, -hh, -hd], [-hw, -hh, hd], [-hw, hh, hd], [-hw, hh, -hd], d, h],
      [[0, 1, 0], [-hw, hh, hd], [hw, hh, hd], [hw, hh, -hd], [-hw, hh, -hd], w, d],
      [[0, -1, 0], [-hw, -hh, -hd], [hw, -hh, -hd], [hw, -hh, hd], [-hw, -hh, hd], w, d],
      [[0, 0, 1], [-hw, -hh, hd], [hw, -hh, hd], [hw, hh, hd], [-hw, hh, hd], w, h],
      [[0, 0, -1], [hw, -hh, -hd], [-hw, -hh, -hd], [-hw, hh, -hd], [hw, hh, -hd], w, h],
    ];
    for (const f of faces) {
      const base = P.length / 3, n = f[0];
      const su = f[5] / TILE, sv = f[6] / TILE;
      const uv = [[0, 0], [su, 0], [su, sv], [0, sv]];
      for (let k = 0; k < 4; k++) {
        const p = f[k + 1];
        P.push(cx + p[0], cy + p[1], cz + p[2]);
        N.push(n[0], n[1], n[2]);
        UV.push(uv[k][0], uv[k][1]);
        C.push(c[0], c[1], c[2]);
      }
      I.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }

  mesh(material) {
    if (!this.pos.length) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nrm, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setIndex(this.idx);
    return new THREE.Mesh(g, material);
  }
}

// Procedural facade textures: daytime wall/glass map and a night emissive map with lit windows
function makeFacadeTextures() {
  const size = 256, cells = 4, cs = size / cells;
  const mk = () => { const c = document.createElement('canvas'); c.width = c.height = size; return c; };
  const wallC = mk(), emC = mk();
  const w = wallC.getContext('2d'), e = emC.getContext('2d');
  w.fillStyle = '#ffffff'; w.fillRect(0, 0, size, size);
  e.fillStyle = '#000000'; e.fillRect(0, 0, size, size);
  for (let i = 0; i < cells; i++) {
    for (let j = 0; j < cells; j++) {
      const x = i * cs + 14, y = j * cs + 16, ww = cs - 28, hh = cs - 34;
      w.fillStyle = '#2c3e52';
      w.fillRect(x, y, ww, hh);
      w.fillStyle = 'rgba(255,255,255,0.18)';
      w.fillRect(x, y, ww, hh * 0.3);
      if (RNG() < 0.45) {
        e.fillStyle = RNG() < 0.8 ? '#ffd27a' : '#bcd9ff';
        e.fillRect(x, y, ww, hh);
      }
    }
  }
  const tex = (cv) => {
    const t = new THREE.CanvasTexture(cv);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return t;
  };
  return { wall: tex(wallC), emissive: tex(emC) };
}

const World = {
  scene: null,
  colliders: {},
  cell: 64,
  signals: [],
  bulbs: {},
  signalY: 0,
  dummy: new THREE.Object3D(),
  buildMat: null,
  lampMat: null,

  coastAt(z) { return -1150 + 45 * Math.sin(z / 260) + 25 * Math.sin(z / 97); },

  // Ground height in metres. The city core is flat at 0; the sea is west, hills east, mountains north.
  heightAt(x, z) {
    const d = x - this.coastAt(z);
    let h = 0;
    if (d < 0) h = -3 - Math.min(10, -d * 0.05);
    else if (d < 60) h = -1 + d / 60;
    const e = x - 950;
    if (e > 0) h += e * e * 0.00005 + Math.sin(x * 0.006) * Math.cos(z * 0.005) * Math.min(12, e * 0.05);
    const m = -z - 1050;
    if (m > 0) h += m * m * 0.00004;
    return h;
  },

  zoneAt(x, z) {
    if (Math.abs(x - 300) < 120 && Math.abs(z - 250) < 120) return 'park';
    if (Math.abs(x + 600) < 80 && Math.abs(z + 400) < 80) return 'park';
    if (x > 450 && z > 350) return 'industrial';
    const d = Math.hypot(x + 150, z + 150);
    if (d < 360) return 'downtown';
    if (d < 650) return 'midtown';
    return 'suburb';
  },

  groundColor(x, z, h) {
    if (h < -0.3) return [0.14, 0.34, 0.4];
    if (x < this.coastAt(z) + 70) return [0.86, 0.79, 0.55];
    if (x > 900) return h > 6 ? [0.42, 0.4, 0.3] : [0.7, 0.6, 0.38];
    return [0.34, 0.5, 0.27];
  },

  addCollider(x0, x1, z0, z1) {
    const cs = this.cell, b = { x0, x1, z0, z1 };
    for (let i = Math.floor(x0 / cs); i <= Math.floor(x1 / cs); i++) {
      for (let j = Math.floor(z0 / cs); j <= Math.floor(z1 / cs); j++) {
        const k = i + ',' + j;
        (this.colliders[k] = this.colliders[k] || []).push(b);
      }
    }
  },

  blocked(x, z, r) {
    const cs = this.cell;
    for (let i = Math.floor((x - r) / cs); i <= Math.floor((x + r) / cs); i++) {
      for (let j = Math.floor((z - r) / cs); j <= Math.floor((z + r) / cs); j++) {
        const list = this.colliders[i + ',' + j];
        if (!list) continue;
        for (const b of list) {
          if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
        }
      }
    }
    return false;
  },

  canStand(x, z, r) {
    const L = CONFIG.MAP_HALF - 30;
    return Math.abs(x) < L && Math.abs(z) < L && this.heightAt(x, z) > CONFIG.SEA_Y + 0.3 && !this.blocked(x, z, r);
  },

  build(scene) {
    this.scene = scene;
    const cfg = CONFIG.CITY, P = cfg.pitch, H = CONFIG.MAP_HALF;
    const x0 = cfg.x0, z0 = cfg.z0, spanX = cfg.nx * P, spanZ = cfg.nz * P, bs = cfg.block;
    const walkTop = 0.18;
    const tex = makeFacadeTextures();
    const vmat = (extra) => new THREE.MeshLambertMaterial(Object.assign({ vertexColors: true, side: THREE.DoubleSide }, extra || {}));
    const add = (b, mat) => { const m = b.mesh(mat); if (m) scene.add(m); };

    // Terrain
    const tg = new THREE.PlaneGeometry(H * 2, H * 2, 180, 180).rotateX(-Math.PI / 2);
    const pa = tg.attributes.position, tc = [];
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i), z = pa.getZ(i), h = this.heightAt(x, z);
      pa.setY(i, h);
      tc.push(...this.groundColor(x, z, h));
    }
    tg.setAttribute('color', new THREE.Float32BufferAttribute(tc, 3));
    tg.computeVertexNormals();
    scene.add(new THREE.Mesh(tg, vmat()));

    // Sea
    const sea = new THREE.Mesh(
      new THREE.PlaneGeometry(H * 2, H * 2).rotateX(-Math.PI / 2),
      new THREE.MeshLambertMaterial({ color: 0x1f6f8b, transparent: true, opacity: 0.88 })
    );
    sea.position.y = CONFIG.SEA_Y;
    scene.add(sea);

    const roadB = new GeoBuilder(), walkB = new GeoBuilder(), propB = new GeoBuilder();
    const lampB = new GeoBuilder(), buildB = new GeoBuilder();
    const trees = [], signals = [];

    // Asphalt slab over the whole grid
    roadB.box(x0 + spanX / 2, 0.01, z0 + spanZ / 2, spanX + cfg.road, 0.02, spanZ + cfg.road, [0.18, 0.18, 0.2]);

    // Lane dashes (skipping intersections)
    for (let k = 0; k <= cfg.nx; k++) {
      const x = x0 + k * P;
      for (let z = z0 + 12; z < z0 + spanZ; z += 14) {
        const rel = (z - z0) % P;
        if (rel > 10 && rel < P - 10) roadB.box(x, 0.03, z, 0.3, 0.02, 6, [0.9, 0.88, 0.75]);
      }
    }
    for (let j = 0; j <= cfg.nz; j++) {
      const z = z0 + j * P;
      for (let x = x0 + 12; x < x0 + spanX; x += 14) {
        const rel = (x - x0) % P;
        if (rel > 10 && rel < P - 10) roadB.box(x, 0.03, z, 6, 0.02, 0.3, [0.9, 0.88, 0.75]);
      }
    }

    // Blocks: sidewalks, parks, buildings and yards
    for (let i = 0; i < cfg.nx; i++) {
      for (let j = 0; j < cfg.nz; j++) {
        const cx = x0 + i * P + P / 2, cz = z0 + j * P + P / 2;
        const zone = this.zoneAt(cx, cz);
        if (zone === 'park') {
          walkB.box(cx, walkTop / 2, cz, bs, walkTop, bs, [0.36, 0.56, 0.3]);
          walkB.box(cx, walkTop + 0.03, cz, 26, 0.06, 18, [0.3, 0.5, 0.75]); // pond
          for (let t = 0; t < 12; t++) trees.push([cx + (RNG() - 0.5) * (bs - 8), cz + (RNG() - 0.5) * (bs - 8)]);
          continue;
        }
        walkB.box(cx, walkTop / 2, cz, bs, walkTop, bs, [0.64, 0.62, 0.58]);
        const n = zone === 'downtown' ? 3 : 2, lot = bs / n;
        const spec = { downtown: [60, 130, 0.97], midtown: [16, 36, 0.92], industrial: [8, 9, 0.85], suburb: [5, 4, 0.7] }[zone];
        for (let a = 0; a < n; a++) {
          for (let b = 0; b < n; b++) {
            const lx = cx - bs / 2 + lot * (a + 0.5), lz = cz - bs / 2 + lot * (b + 0.5);
            if (RNG() > spec[2]) {
              walkB.box(lx, walkTop + 0.02, lz, lot * 0.8, 0.04, lot * 0.8, [0.34, 0.55, 0.28]);
              if (RNG() < 0.5) trees.push([lx + (RNG() - 0.5) * lot * 0.4, lz + (RNG() - 0.5) * lot * 0.4]);
              continue;
            }
            const h = spec[0] + RNG() * spec[1];
            const w = lot * (0.72 + RNG() * 0.2), d = lot * (0.72 + RNG() * 0.2);
            const x = lx + (RNG() - 0.5) * (lot - w), z = lz + (RNG() - 0.5) * (lot - d);
            const c = PALETTE[Math.floor(RNG() * PALETTE.length)];
            buildB.box(x, walkTop + h / 2, z, w, h, d, c);
            this.addCollider(x - w / 2, x + w / 2, z - d / 2, z + d / 2);
          }
        }
      }
    }

    // Street lamps at every intersection corner; traffic signals at inner intersections
    for (let k = 0; k <= cfg.nx; k++) {
      for (let j = 0; j <= cfg.nz; j++) {
        const cx = x0 + k * P, cz = z0 + j * P;
        propB.box(cx + 10, walkTop + 3, cz + 10, 0.28, 6, 0.28, [0.22, 0.22, 0.24]);
        lampB.box(cx + 8.8, walkTop + 6.1, cz + 10, 2.2, 0.25, 0.45, [1, 0.95, 0.8]);
        if (k > 0 && k < cfg.nx && j > 0 && j < cfg.nz) {
          propB.box(cx - 10, walkTop + 2.6, cz - 10, 0.25, 5.2, 0.25, [0.2, 0.2, 0.22]);
          signals.push({ x: cx - 10, z: cz - 10, g: (k + j) % 2 });
        }
      }
    }

    // Hill and mountain trees
    for (let t = 0; t < 650; t++) {
      const x = 900 + RNG() * 850, z = -H + RNG() * 2 * H;
      if (this.heightAt(x, z) > 0.8 && RNG() < 0.55) trees.push([x, z]);
    }

    // Materials and meshes
    this.buildMat = vmat({ map: tex.wall, emissiveMap: tex.emissive, emissive: 0xffe2a0, emissiveIntensity: 0 });
    this.lampMat = new THREE.MeshLambertMaterial({ color: 0xfff1c9, emissive: 0xffc766, emissiveIntensity: 0 });
    add(roadB, vmat());
    add(walkB, vmat());
    add(propB, vmat());
    add(buildB, this.buildMat);
    add(lampB, this.lampMat);

    // Trees as instanced meshes
    if (trees.length) {
      const N = trees.length;
      const trunkG = new THREE.CylinderGeometry(0.35, 0.45, 3.6, 6).translate(0, 1.8, 0);
      const crownG = new THREE.IcosahedronGeometry(2.6, 0).translate(0, 4.8, 0);
      const trunk = new THREE.InstancedMesh(trunkG, new THREE.MeshLambertMaterial({ color: 0x6b4a2b }), N);
      const crown = new THREE.InstancedMesh(crownG, new THREE.MeshLambertMaterial({ color: 0xffffff }), N);
      const dm = new THREE.Object3D(), col = new THREE.Color();
      trees.forEach(([x, z], i) => {
        const s = 0.8 + RNG() * 0.6;
        dm.position.set(x, this.heightAt(x, z), z);
        dm.rotation.y = RNG() * 6;
        dm.scale.set(s, s, s);
        dm.updateMatrix();
        trunk.setMatrixAt(i, dm.matrix);
        crown.setMatrixAt(i, dm.matrix);
        col.setHSL(0.26 + RNG() * 0.06, 0.45 + RNG() * 0.2, 0.2 + RNG() * 0.12);
        crown.setColorAt(i, col);
      });
      trunk.instanceMatrix.needsUpdate = true;
      crown.instanceMatrix.needsUpdate = true;
      crown.instanceColor.needsUpdate = true;
      scene.add(trunk, crown);
    }

    // Traffic signal bulbs (instanced, toggled each frame by updateTraffic)
    this.signals = signals;
    this.signalY = walkTop + 5.4;
    if (signals.length) {
      const sg = new THREE.SphereGeometry(0.26, 8, 6);
      const cols = { r: 0xff3b30, y: 0xffc400, g: 0x34d058 };
      for (const k of ['r', 'y', 'g']) {
        this.bulbs[k] = new THREE.InstancedMesh(sg, new THREE.MeshBasicMaterial({ color: cols[k] }), signals.length);
        scene.add(this.bulbs[k]);
      }
      this.updateTraffic(0);
    }
  },

  updateTraffic(time) {
    if (!this.signals.length) return;
    const t = time % 12;
    const state = (tt) => (tt < 6 ? 'g' : tt < 7 ? 'y' : 'r');
    const sA = state(t), sB = state((t + 6) % 12);
    const offs = { r: -0.35, y: 0, g: 0.35 };
    this.signals.forEach((s, i) => {
      const st = s.g === 0 ? sA : sB;
      for (const k of ['r', 'y', 'g']) {
        this.dummy.position.set(s.x + offs[k], this.signalY, s.z);
        this.dummy.scale.setScalar(st === k ? 1 : 0.0001);
        this.dummy.updateMatrix();
        this.bulbs[k].setMatrixAt(i, this.dummy.matrix);
      }
    });
    for (const k of ['r', 'y', 'g']) this.bulbs[k].instanceMatrix.needsUpdate = true;
  },

  updateLights(night) {
    if (this.lampMat) this.lampMat.emissiveIntensity = night * 1.6;
    if (this.buildMat) this.buildMat.emissiveIntensity = night * 1.1;
  },
};
